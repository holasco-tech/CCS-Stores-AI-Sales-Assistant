# CCS Stores AI Sales Assistant

An AI-powered sales and customer enquiry automation built with **n8n**, **Gmail**, **Google Gemini**, and **Google Sheets**.

## What it does

- Monitors Gmail for new customer enquiries.
- Uses an AI agent to understand PKO and PKC questions.
- Replies professionally with approved product and delivery information.
- Detects when a customer clearly places an order.
- Extracts the customer name, company, product, quantity, and delivery location.
- Records confirmed orders in Google Sheets.
- Avoids recording ordinary enquiries as orders.

## Workflow

`Gmail Trigger → AI Agent → Gmail Reply`

The AI Agent also connects to:

- Google Gemini Chat Model
- Google Sheets order-recording tool

## Business value

This workflow reduces repetitive email handling, improves response speed, and creates a structured order log for follow-up by the sales team.

## Example use case

A customer emails:

> Hello, my name is James from Bright Industries. I would like to order 6 tons of PKO for delivery to Ibadan.

The workflow recognizes the order, extracts the details, appends them to Google Sheets, and sends a professional confirmation email.

## Setup

1. Import `CCS_Stores_AI_Sales_Assistant_PUBLIC.json` into n8n.
2. Connect Gmail credentials to the Gmail Trigger and Gmail Reply nodes.
3. Connect a Google Gemini API credential.
4. Create a Google Sheet with these columns: Customer Name, Company, Product, Quantity, Location.
5. Replace `YOUR_GOOGLE_SHEET_ID` in the Google Sheets node.
6. Test before activation.

## Privacy and security

This public export is sanitized. It does not contain private credential references, workflow IDs, instance IDs, or the original Google Sheet URL.

## Future improvements

- Conversation memory by Gmail thread ID
- Human approval for high-value orders
- Automatic PDF quotation generation
- CRM integration
- Slack or WhatsApp notifications
- RAG knowledge base
- Error handling and retries
